# LICENSE

**NISHKARSH (निष्कर्ष) — Unified Quantitative Convergence Engine**
**Version 1.3.0**

---

## © 2026 @thebullishvalue. All Rights Reserved.

This software and its associated documentation are proprietary and confidential to **@thebullishvalue**.

---

## Terms of Use

### 1. Ownership

This software, including all source code, object code, documentation, algorithms,
mathematical models, and related materials, is the exclusive property of
**@thebullishvalue** and is protected by copyright laws and international treaty
provisions.

### 2. License Grant

This software is provided for **internal use only** by authorised @thebullishvalue
personnel. No rights are granted to:

- Reproduce, distribute, or sublicense the software
- Modify, adapt, or create derivative works
- Reverse engineer, decompile, or disassemble the software
- Use the software for commercial purposes outside @thebullishvalue

### 3. Confidentiality

The algorithms, methodologies, and implementation details contained in this
software constitute trade secrets of @thebullishvalue. Recipients agree to:

- Maintain strict confidentiality of all proprietary information
- Limit access to authorised personnel only
- Not disclose any technical details to third parties

### 4. No Warranty

This software is provided **"AS IS"** without warranty of any kind, express or
implied, including but not limited to:

- Merchantability or fitness for a particular purpose
- Non-infringement of third-party rights
- Accuracy, completeness, or reliability of outputs
- Suitability for financial decision-making or trading

### 5. Limitation of Liability

In no event shall @thebullishvalue or its affiliates be liable for:

- Any direct, indirect, incidental, special, or consequential damages
- Loss of profits, data, or business opportunities
- Claims arising from use or inability to use the software
- Investment decisions or financial losses based on software outputs

### 6. Academic References

This software implements mathematical methods from published academic research:

- Andrews, D.W.K. (1993). *Exactly Median-Unbiased Estimation of First-Order Autoregressive/Unit Root Models.* Econometrica.
- Bai, J. & Perron, P. (2003). *Computation and Analysis of Multiple Structural Change Models.* J. Applied Econometrics.
- Peng, C.K. *et al.* (1994). *Mosaic Organization of DNA Nucleotides.* Physical Review E.
- Ratcliff, R. & McKoon, G. (2008). *The Diffusion Decision Model.* Neural Computation.

These references are cited for attribution purposes only and do not constitute
endorsement by the original authors or their institutions.

### 7. Compliance

Users agree to comply with all applicable laws and regulations, including:

- Securities and exchange regulations
- Data protection and privacy laws
- Export control regulations

### 8. Termination

This licence is effective until terminated. @thebullishvalue reserves the right
to terminate this licence at any time for breach of terms.

---

## Version History

| Version | Date | Description |
|---------|------|-------------|
| 1.3.0 | 2026-05-25 | Resilient Convergence — Smart data layer + Pragyam UI parity |
| 1.2.0 | 2026-04-13 | Obsidian Quant Terminal — Standardisation pass |
| 1.1.0 | 2026-04-07 | Nishkarsh Production Release — Unified convergence engine |
| 1.0.0 | 2026-04-05 | Initial Nishkarsh Release — Aarambh + Nirnay unification |

---

## Contact

**@thebullishvalue**

For licensing inquiries or permissions, contact:
📧 @thebullishvalue

---

**Last Updated:** 2026-05-25

**By using this software, you acknowledge that you have read, understood, and
agree to be bound by these terms and conditions.**

---

*निष्कर्ष (Nishkarsha) means "conclusion" or "inference" in Sanskrit —
the synthesis of evidence into judgement.*
